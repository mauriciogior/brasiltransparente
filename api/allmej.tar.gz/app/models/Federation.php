<?php

class Federation extends Eloquent {

	protected $table = 'federations';

}