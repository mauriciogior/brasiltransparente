<?php

class Common extends Eloquent {

	protected $table = 'common';
	
}