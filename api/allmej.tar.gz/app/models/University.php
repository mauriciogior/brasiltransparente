<?php

class University extends Eloquent {

	protected $table = 'universities';

}